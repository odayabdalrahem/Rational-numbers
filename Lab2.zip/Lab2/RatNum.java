import java.math.BigInteger;  
/**
 * A class for creating a rational number.
 * Takes two variables, one for the numerator and one for the denominator
 * @author Odai and Theo 
 * @version 13/09/2022
 */
public class RatNum
{
    
    public static void main (String[] arg) {
        
    }
    
    private int NumeratorT;
    private int DenominatorN;
    
    /**
     * Initializes a newly created RatNum object so that it represents 0 as a rational number.
     */
    public RatNum() {
        NumeratorT = 0;
        DenominatorN = 1;
    }
    
    /**
     * Constructs a RatNum object with parameter a as a rational number.
     */
    public RatNum(int a) {
        NumeratorT = a;
        DenominatorN = 1;
    }
    
    /**
     * Constructs a RatNum object with a as the numerator and b as the denominator
     */
    public RatNum(int a, int b) {
        
        if (b<0) {
            a = -a;
            b = -b;
        }
        int temp = gcd(a,b);
        if (b != 0) {
            if (temp != 0) {
                a = a/temp;
                b = b/temp;
            }
        } else {
            throw new NumberFormatException("Denominator = 0");
        }
        NumeratorT = a;
        DenominatorN = b;    
    }
    
    /**
     * Constructs a RatNum object as a copy of the RatNum parameter r 
     */
    public RatNum(RatNum r) {
        NumeratorT = r.NumeratorT;
        DenominatorN = r.DenominatorN;
    }
    
    /**
     * Constructs a RatNum object from a String parameter s 
     */
    public RatNum(String s) {
        this(RatNum.parse(s));
    }  
    
    /**
     * Returns the numerator of the RatNum object
     */
    public int getNumerator() {
        return NumeratorT;
    }
    
    /**
     * Returns the denominator of the RatNum object
     */
    public int getDenominator() {
        return DenominatorN;
    }
    
    /**
     * Returns the RatNum object as a String
     */
    public String toString(){
        String o = String.valueOf(NumeratorT);
        String q = String.valueOf(DenominatorN);
        return (o + "/" + q);
    }
    
    /**
     * Creates a new rational number with the given value of the String parameter s and returns a reference to the new rational number
     */
    public static RatNum parse(String s) {
        String numerator_string = "";
        String denominator_string = "";
        boolean numerator_done = false;
        
        for(int i = 0; i < s.length(); i++) {
            if (!numerator_done) {
                if (s.charAt(i) == '/') {
                    numerator_done = true;
                } else {
                    numerator_string = numerator_string + s.charAt(i);
                }
            } else {
                denominator_string = denominator_string + s.charAt(i);
            }
        }
        
        if (!numerator_done) {
            denominator_string = "1";
        }
        
        int tempNum = Integer.parseInt(numerator_string);
        int tempDen = Integer.parseInt(denominator_string);
        
        RatNum tempRatNum = new RatNum(tempNum, tempDen);
        return tempRatNum;
    }
    
    /**
     * Compares if the RatNum object is less than the given RatNum parameter
     */
    public boolean lessThan(RatNum r) {
        boolean res = false;
        
        int r_value = r.NumeratorT * DenominatorN;
        int value = NumeratorT * r.DenominatorN;
        
        if (value < r_value) {
            res = true;
        }
        
        return res;
    }
    
    /**
     * Returns the sum of the RatNum object and the RatNum parameter r
     */
    public RatNum add(RatNum r) {
        int ad = NumeratorT * r.DenominatorN;
        int bc = DenominatorN * r.NumeratorT;
        int bd = DenominatorN * r.DenominatorN;
        
        RatNum res = new RatNum((ad + bc), bd);
        
        return res;
    }
    
    /**
     * Returns the difference of the RatNum object and the RatNum parameter r
     */
    public RatNum sub(RatNum r) {
        int ad = NumeratorT * r.DenominatorN;
        int bc = DenominatorN * r.NumeratorT;
        int bd = DenominatorN * r.DenominatorN;
        
        RatNum res = new RatNum((ad - bc), bd);
        
        return res;
    }
    
    /**
     * Returns the product of the RatNum object and the RatNum parameter r
     */
    public RatNum mul(RatNum r) {
        int mulNum = NumeratorT * r.NumeratorT;
        int mulDen = DenominatorN * r.DenominatorN;
        
        RatNum res = new RatNum(mulNum, mulDen);
        
        return res;
    }
    
    /**
     * Returns the division of the RatNum object and the RatNum parameter r
     */
    public RatNum div(RatNum r) {
        int mulNum = NumeratorT * r.DenominatorN;
        int mulDen = DenominatorN * r.NumeratorT;
  
        RatNum res = new RatNum(mulNum, mulDen);
        
        return res;
    }
    
    
    /**
     * Returns the RatNum object as string
     */
    public String toIntString() {
        int temp = 0;
        
        temp = NumeratorT / DenominatorN; 
        
        String res = String.valueOf(temp);
        return res;
    }
    
    /**
     * Compares a RatNum object to the RatNum parameter r. Returns true if equal.
     */
    public boolean equals(Object r) {
        if(r == null) {return false;} 
        if (r.getClass() != this.getClass()) {return false;}
        RatNum p = (RatNum)r;
        int ad = NumeratorT * p.DenominatorN;
        int bc = DenominatorN * p.NumeratorT;
       
        if (ad == bc) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Classfunction that returns the greatest common multiple of the parameters m and n.
     */
    public static int gcd(int m, int n)
    {   
        
        int gcd = 1;
        
        if (m<0) {
            m = -m;   
        }
        if (n<0) {
            n = -n;
        }
        

        if (m == 0 || n == 0) {
            if (m>n) {
                return m;
            } else if (n>m) {
                return n;
            } else {
                throw new IllegalArgumentException();
            }
        } else {
            for(int i = 1; i <= m && i <= n; i++)  {   
                if(m%i==0 && n%i==0)  {
                gcd = i;  
                }
            }  
            return gcd;
        }
    }
}
